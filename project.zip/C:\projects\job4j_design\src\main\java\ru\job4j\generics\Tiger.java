package ru.job4j.generics;

public class Tiger extends Predator {
}
